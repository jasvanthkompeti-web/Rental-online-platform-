const products=[
{id:1,name:"MacBook Air M2",type:"Laptop",brand:"Apple",price:999,deposit:5000,img:"https://images.unsplash.com/photo-1517336714739-489689fd1ca8",desc:"13-inch laptop for study, coding and work."},
{id:2,name:"Dell XPS 15",type:"Laptop",brand:"Dell",price:899,deposit:4500,img:"https://images.unsplash.com/photo-1593642702821-c8da6771f0c6",desc:"Powerful laptop for professional work."},
{id:3,name:"iPhone 15 Pro",type:"Phone",brand:"Apple",price:799,deposit:5000,img:"https://images.unsplash.com/photo-1695048133142-1a20484d2569",desc:"Premium iPhone for photography and entertainment."},
{id:4,name:"Samsung Galaxy S24",type:"Phone",brand:"Samsung",price:599,deposit:3500,img:"https://images.unsplash.com/photo-1610945415295-d9bbf067e59c",desc:"Modern smartphone with a high-quality display."},
{id:5,name:"Sony Alpha Camera",type:"Camera",brand:"Sony",price:699,deposit:4000,img:"https://images.unsplash.com/photo-1516035069371-29a1b244cc32",desc:"Mirrorless camera for travel and events."},
{id:6,name:"Canon EOS Camera",type:"Camera",brand:"Canon",price:599,deposit:3500,img:"https://images.unsplash.com/photo-1502920917128-1aa500764cbd",desc:"Digital camera for photography."},
{id:7,name:"iPad Air",type:"Tablet",brand:"Apple",price:499,deposit:3000,img:"https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0",desc:"Lightweight tablet for study and design."},
{id:8,name:"PlayStation 5",type:"Gaming",brand:"Sony",price:699,deposit:4000,img:"https://images.unsplash.com/photo-1606813907291-d86efa9b94db",desc:"Gaming console for entertainment."}
];
let cart=JSON.parse(localStorage.getItem("rentxCart")||"[]");

function save(){localStorage.setItem("rentxCart",JSON.stringify(cart));renderCart();updateCount()}
function updateCount(){count.textContent=cart.reduce((s,x)=>s+x.qty,0)}
function showProducts(list=products){
 productsEl=document.getElementById("products");
 productsEl.innerHTML=list.map(p=>`<article class="card"><img src="${p.img}"><div class="cardbody"><span>${p.type}</span><h3>${p.name}</h3><p>${p.brand} • ${p.desc}</p><strong>₹${p.price}/day</strong><button class="btn small" onclick="add(${p.id})">Add to Cart</button></div></article>`).join("");
}
function add(id){let p=products.find(x=>x.id===id),x=cart.find(x=>x.id===id);if(x)x.qty++;else cart.push({...p,qty:1});save();location.hash="cart"}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save()}
function change(id,n){let x=cart.find(x=>x.id===id);if(x){x.qty=Math.max(1,x.qty+n);save()}}
function renderCart(){
 let el=document.getElementById("cartItems");
 if(!cart.length){el.innerHTML='<div class="empty">Your cart is empty. <a href="#products">Browse electronics</a></div>';cartTotal.innerHTML="";return}
 el.innerHTML=cart.map(x=>`<div class="cartrow"><img src="${x.img}"><div class="grow"><b>${x.name}</b><p>₹${x.price}/day</p></div><button onclick="change(${x.id},-1)">−</button><b>${x.qty}</b><button onclick="change(${x.id},1)">+</button><button onclick="removeItem(${x.id})">✕</button></div>`).join("");
 cartTotal.innerHTML='<div class="totalbox"><h3>Rental items: '+cart.reduce((s,x)=>s+x.qty,0)+'</h3><a class="btn" href="#checkout">Continue to Checkout</a></div>';
 calculate();
}
function filter(type){showProducts(products.filter(p=>p.type===type))}
function showAll(){showProducts()}
search.oninput=()=>showProducts(products.filter(p=>(p.name+" "+p.brand+" "+p.type).toLowerCase().includes(search.value.toLowerCase())));

function days(){if(!start.value||!end.value)return 0;return Math.ceil((new Date(end.value)-new Date(start.value))/86400000)}
function calculate(){
 let d=days();let rental=cart.reduce((s,x)=>s+x.price*x.qty,0)*Math.max(d,0);let dep=cart.reduce((s,x)=>s+x.deposit*x.qty,0);
 estimate.textContent=d>0?"Rental: ₹"+rental+" + Deposit: ₹"+dep+" = Total: ₹"+(rental+dep):"Choose valid rental dates";
 bill.innerHTML=cart.length?cart.map(x=>`<p>${x.name} × ${x.qty} = ₹${x.price*x.qty*d}</p>`).join("")+(d>0?`<hr><p>Rental subtotal: ₹${rental}</p><p>Security deposit: ₹${dep}</p><h2>Payable: ₹${rental+dep}</h2>`:""):"<p>Add products to your cart.</p>";
}
start.onchange=end.onchange=calculate;

function payNow(){
 if(!cart.length)return paymentMsg.textContent="Please add an electronic item first.";
 if(!name.value||!email.value||!phone.value||!start.value||!end.value||days()<1)return paymentMsg.textContent="Please complete your details and choose valid dates.";
 let d=days(),rental=cart.reduce((s,x)=>s+x.price*x.qty,0)*d,dep=cart.reduce((s,x)=>s+x.deposit*x.qty,0),total=rental+dep;
 let invoice="RX"+Date.now();
 localStorage.setItem("lastInvoice",JSON.stringify({invoice,name:name.value,email:email.value,start:start.value,end:end.value,days:d,total,items:cart}));
 paymentMsg.innerHTML=`<b class="paid">✓ PAYMENT SUCCESSFUL</b><br>Invoice: ${invoice}<br>Amount Paid: ₹${total}<br><button class="btn small" onclick="printBill()">Print Bill</button>`;
 cart=[];save();
}
function printBill(){let x=JSON.parse(localStorage.getItem("lastInvoice"));let w=window.open("","_blank");w.document.write(`<h1>RentX Rental Bill</h1><p>Invoice: ${x.invoice}</p><p>Customer: ${x.name}<br>Email: ${x.email}</p><p>Rental: ${x.start} to ${x.end} (${x.days} days)</p><hr>${x.items.map(i=>`<p>${i.name} × ${i.qty}</p>`).join("")}<h2>Total Paid: ₹${x.total}</h2>`);w.print()}
showProducts();renderCart();updateCount();